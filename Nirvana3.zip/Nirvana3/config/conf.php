<?php
$servidor="127.0.0.1";
$usuario="root";
$clave="";
$puerto=3306;
$baseDatos="nirvana";
?>