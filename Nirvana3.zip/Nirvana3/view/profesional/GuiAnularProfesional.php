<section id="middle">
	<form name="frm_persona" method="post" enctype="multipart/form-data"  action="<?php echo getUrl("profesional", "profesional", "postAnularProfesional"); ?>">
	<div id="content" class="padding-20">
            <?php foreach($profesional as $profe){} ?>
		<!-- Rounded Switcher -->
		<div class="panel panel-default">
			<div class="panel-body">
				
                            <div class="col-md-2 col-lg-4"><strong class="letraMedium">Profesional</strong></div>
                            <div class="col-md-4">
                                    <a href="<?php echo getUrl("profesional", "profesional", "crearProfesional");?>" class="btn btn-primary" title="Nuevo Profesional">
                                                                    <i class="fa fa-file fa-lg"></i>
                                    </a>						
                                    <button type="submit" class="btn btn-primary" title="Guardar Profesional">
                                                                    <i class="fa fa-save fa-lg"></i>
                                    </button>
                                    <!--<a href="#" data-url="<?php echo getUrl("profesional", "profesional", "buscarProfesional", "", "ajax");?>" id="btn_buscarProfesional" class="btn btn-primary" title="Buscar Profesional">
                                                                    <i class="fa fa-search fa-lg"></i>
                                    </a>-->
                                   <!-- <a href="#" data-url="<?php echo getUrl("Empleado", "Empleado", "crearNovedadEmpelado", "", "ajax");?>" id="btn_novedadEmpleado" class="btn btn-primary" title="Registrar Novedad">
                                                                    <i class="fa fa-file-text fa-lg"></i>
                                    </a>-->
                                    <!--<a href="<?php echo getUrl("profesional", "profesional", "anularProfesional");?>" class="btn btn-primary" title="Eliminar Profesional">
                                                                    <i class="fa fa-trash-o fa-lg"></i>
                                    </a>-->
                            </div>
			</div>																			
		</div>
					
		<div id="panel-ui-tan-l3" class="panel panel-default">
			<div class="panel-body">		
				<div class="tabs nomargin">		
					<ul class="nav nav-tabs">
						<li class="active">
							<a href="#tab1_nobg" data-toggle="tab">
								<i class="fa fa-pencil-square-o"></i> <b>Datos Básicos</b>
							</a>
						</li>
						
						
						
						
					</ul>		
					<div class="tab-content transparent">
					
						<div id="tab1_nobg" class="tab-pane active">
							<div class="borde_form">
                                                            <div class="row">
                                                                <div class="col-md-12">
																	<div class="col-md-3">Tipo Identidad *
                                                                            <input type="text" required name="tipo_id" readonly class="form-control" value="<?php echo$profe['ti_sigla'] ?>">
                                                                    </div>
                                                                    <div class="col-md-3">No Identificación *
                                                                            <input type="text" required name="identificacion" readonly class="form-control" value="<?php echo$profe['identificacion'] ?>">
                                                                    </div>
																	<div class="col-md-3">No Registro *
                                                                            <input type="text" required name="no_registro" readonly class="form-control" value="<?php echo$profe['no_registro'] ?>">
                                                                    </div>
																	<div class="col-md-3">Genero <input type="text" name="genero" readonly class="form-control" value="<?php echo$profe['sexo'] ?>"></div>
                                                                            
                                                                   	
                                                                    										
																</div>
															</div>
                                                            <div class="row">
                                                                    <div class="col-md-12">																					
                                                                            <div class="col-md-3">Nombres *<input type="text" name="nombres" readonly required class="form-control" value="<?php echo$profe['nombres'] ?>"></div>											
                                                                            <div class="col-md-3">Primer Apellido *<input type="text" name="ape1" readonly required class="form-control" value="<?php echo$profe['apellido1'] ?>"></div>											
                                                                            <div class="col-md-3">Segundo Apellido <input type="text" name="ape2" readonly class="form-control" value="<?php echo$profe['apellido2'] ?>"></div>
                                                                            <div class="col-md-3">Ciudad *<input type="text" name="ciudad_res" readonly required class="form-control" value="<?php echo$profe['ciudad'] ?>"></div>											
                                                                            
                                                                    </div>

                                                            </div>
															<div class="row">
																		<div class="col-md-12">
																			<div class="col-md-3">Telefono 1 *<input type="text" name="tel1" readonly required class="form-control" value="<?php echo$profe['telefono1'] ?>"></div>
                                                                            <div class="col-md-3">Telefono 2 *<input type="text" name="tel2" readonly required class="form-control" value="<?php echo$profe['telefono2'] ?>"></div>											
                                                                            <div class="col-md-3">Celular *<input type="text" name="celular" readonly required class="form-control" value="<?php echo$profe['celular'] ?>"></div>											
																			<div class="col-md-3">Especialidad *<input type="text" name="especialidad" readonly required class="form-control" value="<?php echo$profe['especialidad'] ?>"></div>											
                                                                            
																		</div>
															</div>
															<div class="row">
                                                                    <div class="col-md-12">
																			
                                                                            <div class="col-md-4">Email Personal *<input type="text" name="email" readonly required class="form-control" value="<?php echo$profe['email'] ?>"></div>											
                                                                            <div class="col-md-5">Direccion<input type="text" name="direccion" readonly class="form-control" value="<?php echo$profe['direccion'] ?>"></div>
                                                                            <div class="col-md-3">Estado *<input type="text" name="estado" required class="form-control" value="<?php echo$profe['estado'] ?>"></div>											
                                                                            																											
                                                                    </div>
                                                            </div>
                                                            
										
                                                           
                                                            			
                                                            
																																		
								
							
							</div>
						</div>

						
						
						
						
						
					</div>

				</div>
			</div>
		</div>
		
	</div>

</div>
	</form>
<div class="modal fade" id="modalVerArchivo" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-full">
            <div class="modal-content">

                    <!-- header modal -->
                    <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4><label id="tituloModal"></label></h4>
                    </div>

                    <!-- body modal -->
                    <div class="modal-body">
                         
                        <div id="div_contenedor"></div>
                                   
                    </div>

            </div>
    </div>
</div>
    
<div class="modal fade" id="modalNovedadEmpleado" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
            <div class="modal-content">

                    <!-- header modal -->
                    <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4><label id="tituloModal"></label></h4>
                    </div>

                    <!-- body modal -->
                    <div class="modal-body">
                         
                        <div id="div_contenedorNovedad"></div>
                                   
                    </div>

            </div>
    </div>
</div>
<script src="../view/profesional/js/profesional.js"></script>
</section>