<div class="card-body">
<form method="post" id="frm_ModalBuscarProfesional" action="<?php echo getUrl("profesional", "profesional", "ListarProfesional", "", "ajax");?> " autocomplete="off">		           		
	<div class="container-fluid">
		 <div class="row">
			<label class="font-weight-bold">Digite los primeros caracteres</label>
		</div>
	<div class="align-items-center p-4 border row">
			<div class="borde_form">
       
            
                <div class="col-12">
					<div class="row">

						<div class="col-2">
							<label class="font-weight-bold" for="estado">Estado</label>
							<select name="estado" id="estado" class="estado form-control">
								<option value="">Seleccione ...</option>
								<option value="T">Todos</option>
								<option value="A" selected>Activos</option>
								<option value="I">Inactivos</option>
							</select>
						</div>

						<div class="col-2">
							<label class="font-weight-bold" for="cedula">Cedúla</label>
							<input type="text" name="cedula" id="cedula" class="form-control">
						</div>

						<div class="col-2">
							<label class="font-weight-bold" for="nombre">Nombre</label>
							<input type="text" name="nombre" id="nombre" class="form-control">
						</div>

						<div class="col-2">
							<label class="font-weight-bold" for="especialidad">Especialidad</label>
                        <input type="text" name="especialidad" id="especialidad" class="form-control">
						</div>
						
						<div class="col-4 center-block">
						<div class="row"style="margin-top: 24px;">
							<div class="col-sm-6">

							<div id="menu-ver-editar-profesional" class="row" style="display: none;">

								<div class="col-5">
									<div class="btn-group" role="group">
										<div class="btn-group" role="group">
											<a href="javascript:void(0);" target="_blank" class="btn btn-primary px-3 py-2" id="btnVerProfesional" role="button">Ver</a>
										</div>
									</div>
								</div>

								<div class="col-sm-4">
									<div class="btn-group" role="group">
										<div class="btn-group" role="group">
											<a href="javascript:void(0);" target="_blank" class="btn btn-primary px-3 py-2" id="btnEditarProfesional" role="button">Editar</a>
										</div>
									</div>
								</div>
	
							</div>
							</div>
						

						<div class="col-sm-6">
							<button type="submit" class="px-3 py-2 btn btn-primary" id="btnModalBuscarProfesional" title="Buscar">
								<i class="fa fa-search"></i>
							</button>
							<button type="reset" class="px-3 py-2 btn btn-primary" id="btnNuevaBusqueda" title="Nueva búsqueda">
								<i class="fa fa-file"></i>
							</button>
						</div>
							
						
						</div>
							
						
			
					</div>
					</div>
					
					
				</div>             
                
                
            
        
		</div>
	</div>
    
	</div>
   
</form>
</div>
<div class="container">
    
        
            	
                
                    <div id="containerTablaModalBuscarProfesional" style="display: none;">
                        
                            <table id="tablaModalBuscarProfesional" class="table table-bordered table-hover" width="100%;">
                                <thead class="text-white bg-primary thead-primary">
                                    <tr>
                                        <th>Cedúla</th>
                                        <th>Nombre</th>
                                        <th>Especialidad</th>
                                        <th>Estado</th>
                                    </tr>
                                </thead>
                                <tbody>
                            </table>
                        
                    </div>
                
           
       
    
</div>