$(document).ready(function() {
 
    $(document).on("click", "#btn_buscarProfesional", function(){    
       var url=$(this).attr('data-url');     
        $.ajax({
            url:url,
            success: function(data){
               $('#div_contenedor').html(data);
               $('#tituloModal').text("Búsqueda de Profesional");
               $('#modalVerArchivo').modal('show');
            }
        });     
    });
  
    $(document).on("submit", "#frm_ModalBuscarProfesional", function(event){  
        event.preventDefault();
        
         if ($("#cedula").val() || $("#nombre").val() || $("#especialidad").val() || $("#estado").val()) {
             $("#containerTablaModalBuscarProfesional").show();
             $("#menu-ver-editar-profesional").hide();

             var tablaModalBuscarProfesional = $("#tablaModalBuscarProfesional").DataTable({
                // dom: "Bfrtip",
                // buttons: [{
                //     extend: "excelHtml5",
                //     text: '<i class="fa fa-file-excel"></i>',
                //     titleAttr: "Exportar a Excel",
                //     className: "bg-success",
                //     filename: "Empleados",
                //     sheetName: "Empleados"
                // }],
                language: {
                    "url": "../../vendor/assets/plugins/datatables/language/datatablesSpanish.json"
                },
                destroy: true,
                pageLength: 10,
                autoWidth: true,
                lengthChange: false,
                columnDefs: [{
                    "className": "text-center",
                    "targets": "_all"
                }],
                ajax: {
                    url: $(this).prop("action"),
                    method: $(this).prop("method"),
                    data: {
                        "cedula": $("#cedula").val(),
                        "nombre": $("#nombre").val(),
                        "especialidad": $("#especialidad").val(),
                        "estado": $("#estado").val()
                    },
                },
                columns: [
                    { data: "cedula" },
                    { data: "nombre" },
                    { data: "especialidad" },
                    { data: "estado" }
                ],
            });
        }
       /*
            swal({
                    type: "warning",
                    title: "Seleccione un criterio de búsqueda"
            });
        }*/
    });

    $(document).on("click", "#tablaModalBuscarProfesional a", function(){
        let data = $("#tablaModalBuscarProfesional").DataTable().row($(this).parents("tr")).data();

        $("#menu-ver-editar-profesional").hide();
        $("#menu-ver-editar-profesional").show(500);

        let pagina = "index.php";
        let modulo = "?modulo=profesional";
        let controlador = "&controlador=profesional";
        let parametros = `&cedula=${$(data.cedula).text()}`;
		
		$(document).on("click", "#btnVerProfesional", function(){
            let funcion = "&funcion=verProfesional";
            let url = pagina + modulo + controlador + funcion + parametros;
            $(this).attr("href", url);
        });

        $(document).on("click", "#btnEditarProfesional", function(){
            let funcion = "&funcion=editarProfesional";
            let url = pagina + modulo + controlador + funcion + parametros;
            $(this).attr("href", url);
        });
    });
  
  $(document).on("click", "#btn_novedadProfesional", function(){
    var url=$(this).attr('data-url');
    var cedula=$('#identificacion').val();
    var especialidad=$('#especialidad').val();
	
	alert(cargo);
    $.ajax({
        url:url,
        success: function(data){
           $('#div_contenedorNovedad').html(data);  
           $('#cedula').val(cedula);
           $('#especialidad').val(cargo);
           $('#modalNovedadEmpleado').modal('show');
        }
    });     
  });
  
  $(document).on("blur", "#no_registro", function(){
		var num_registro=$('#no_registro').val();
		var url=$(this).attr('data-url');
		$.ajax({
			url: url,
			data:"num_reg="+num_registro,
			type: 'POST',
			success:function(resultado){
				if(resultado === "true"){
					alert("El Número de Registro del Profesional ya Existe !!");
					/*swal({
						type:"warning",
						title:"El Número de Registro del Profesional ya Existe !!", 
						showCancelButton:true,
						confirmButtonColor: "#337ab7"
						
					});*/
				}
			}
		});
	});
	
  $(document).on("click", "#btn_anularProfesional", function(){
	 console.log($("#frmEditarProfesional"))
	 var formData = ($("#frmEditarProfesional")[0]);
	 
	 alertify.confirm("Está seguro que sea eliminar el registro", function(){
			// prompt dialog<font></font>
				alertify.prompt("Message", function (e, str) {
					// str is the input text<font></font>
					if (e) {
						// user clicked "ok"<font></font>
					} else {
						// user clicked "cancel"<font></font>
					}
				}, "Default Value");
//alertify.success("Registro eliminado con éxito");
	  });
  });
    
$(function anularProfesional() {
		$(document).on("click", "#anularProfesional", function () {
			let estado = $("span:contains(ACTIVO)").length == 1 ? "ACTIVO" : "ANULADO";
			
			if (estado == "ACTIVO") {
				alertify.confirm(//html
					`<h4>Está segur(a) que desea eliminar al Profesinal</h4>`
				).set({
					closable: false,
					labels: { ok: "Sí", cancel: "No" },
					onok: () => {
						$.ajax({
							url: "ajax.php?modulo=profesional&controlador=profesional&funcion=anularProfesional",
							method: "post",
							data: new FormData($("#frmpersonaEditar")[0]),
							dataType: "json",
							processData: false,
							contentType: false
						}).done((res) => {
							alertify.notify(res.mensaje, res.tipoRespuesta, 4, () => {
								if (res.tipoRespuesta == "success") {
									window.location.reload();
								}
							});
						});
					},
				}).setHeader("");
			} else if (estado == "ANULADO") {
				alertify.notify("El registro se encuentra anulado", "warning", 4);
			}
		});
	});	
	
	
	
	
	
});

