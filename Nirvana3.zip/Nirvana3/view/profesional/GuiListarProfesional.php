<table class="table table-hover ">
    <thead>
        <tr>
           <th>#</th>
            <th>Cedúla</th>
            <th>Nombre</th>
            <th>Especialidad</th>
            <th>Estado</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if($listarprofe->num_rows >0){
            $i=1;
            foreach($listarprofe as $listProf){
                echo"<tr class='verIconoEditar' data-idProf='".$listProf['identificacion']."'>";
                    echo"<td>".$i."</td>";
                    echo"<td>".$listProf['identificacion']."</td>";
                    echo"<td>".$listProf['Nombre_Completo']."</td>";                  
                    echo"<td>".$listProf['especialidad']."</td>";                   
                    echo"<td>".$listProf['estado']."</td>";                   
                echo"</tr>";
                $i++;
            }
            
        }
        else{
            echo '<td>No hay Registros</td>';
        }
        ?>
    </tbody>
</table>