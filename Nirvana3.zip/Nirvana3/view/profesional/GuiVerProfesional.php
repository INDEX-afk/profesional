<form name="frm_persona" method="post" enctype="multipart/form-data"  action="<?php echo getUrl("profesional", "profesional", "postVerProfesional"); ?>">
	<div class="row">
		<div class="col-12">
			<div class="page-header">
				<?php foreach($profesional as $profe){} ?>
				<div class="pb-3 align-items-center row">
					<div class="col-4">
						<h2 class="pageheader-title">Profesional</h2>
					</div>
					
					<div class="col-6">
						<a href="<?php echo getUrl("profesional", "profesional", "VistaCrearProfesional");?>" class="btn btn-primary" title="Nuevo Profesional">
										<i class="fa fa-file fa-lg"></i>
						</a>


						<a href="javascript:void(0);" class="btn btn-primary" title="Buscar Profesional" data-url="<?php echo getUrl("profesional", "profesional", "buscarProfesional", "", "ajax");?>" id="btn_buscarProfesional">
							<i class="fa fa-search fa-lg"></i>
						</a>
					</div>
					
					<div class="col-2">
						<?php if($profe["estado"]=="A"){
							echo "<h4><span class='badge badge-primary'>ACTIVO</span></h4>";
							
						}else{
							
								echo"<h4><span class='badge badge-danger'>ANULADO</span></h4>";
								
						}
						
						?>	
					</div>
				</div>

				
			</div>
		</div>
	</div>

					
		<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<div class="card-body">
					<div class="mt-4 row">
						<div class="col-12">

							<div class="card">
								<div class="card-header">
									<ul class="nav nav-tabs">
										<li class="nav-item">
											<a class="nav-link active" data-toggle="tab" href="#datos_basicos" role="tab">
												<i class="fa fa-edit"></i>
												<b>Datos Básicos</b>
											</a>
										</li>
										
									</ul>
								</div>

								<div class="card-block">
									<div class="tab-content">
										<div class="tab-pane active" id="datos_basicos">
											<div class="container-fluid">
												<div class="row">
													<div class="col-12">
														<div class="row">
															<div class="col-5">
																<div class="form-group row">
																	<div class="col-12">Tipo de Identidad *
                                                                                   <input type="text" required name="tipo_id" readonly class="form-control" value="<?php echo$profe['ti_sigla'] ?>">
                                                                   
																	</div>
																</div>
															</div>

															<div class="col-4">
																<div class="form-group row">
																	<div class="col-12">No Identificacion*
																	<input type="text" required readonly name="identificacion" readonly class="form-control" value="<?php echo$profe['identificacion'] ?>">
                                                                    </div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">No. Registro*
																	       <input type="text" required readonly name="no_registro" readonly class="form-control" value="<?php echo$profe['no_registro'] ?>">
                                                                    </div>
																</div>
															</div>
														</div>

														<div class="row">
															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">Genero *
                                                                                <input type="text" name="genero" readonly class="form-control" value="<?php echo$profe['sexo'] ?>">
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		Nombres *<input type="text" readonly name="nombres" required class="form-control" value="<?php echo$profe['nombres'] ?>"></div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		Primer Apellido *<input type="text" readonly name="ape1" required class="form-control" value="<?php echo$profe['apellido1'] ?>"></div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		Segundo Apellido <input type="text" readonly name="ape2" class="form-control" value="<?php echo$profe['apellido2'] ?>"></div>
																</div>
															</div>
														</div>

														<div class="row">
															<div class="col-6">
																<div class="form-group row">
																	<div class="col-12">Ciudad de Residencia *
                                                                                    <input type="text" name="ciudad_res" readonly required class="form-control" value="<?php echo$profe['ciudad'] ?>">
                                                                            </div>
																	</div>
																</div>
																
															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">Especialidad *<input type="text" readonly name="especialidad" required class="form-control" value="<?php echo$profe['especialidad'] ?>"></div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		Telefono 1 *<input type="text" readonly name="tel1" required class="form-control" value="<?php echo$profe['telefono1'] ?>">
																	</div>
																</div>
															</div>
														</div>
														

															

														<div class="row">
															<div class="col-4">
																<div class="form-group row">
																	<div class="col-12">
																		Teléfono 2<input type="text" readonly name="tel2" class="form-control" value="<?php echo$profe['telefono2'] ?>">
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		Celular<input type="text" readonly name="celular" class="form-control" value="<?php echo$profe['celular'] ?>"></div>
																</div>
															</div>

															<div class="col-5">
																<div class="form-group row">
																	<div class="col-12">
																		Email Personal *<input type="text" readonly name="email" required class="form-control" value="<?php echo$profe['email'] ?>">
																	</div>
																</div>
															</div>
														</div>
														<div class="row">
															<div class="col-12">
																<div class="form-group row">
																	<div class="col-12">
																		Dirección *<input type="text" readonly name="direccion" required class="form-control" value="<?php echo$profe['direccion'] ?>"></div>
																</div>
															</div>

															

																											
														</div>

													</div>
												</div>

													
												</div>
											</div>
										</div>

										
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	
</form>

<!-- MODAL BUSCAR EMPLEADO-->

<div class="modal fade" id="modalVerArchivo">
	<div class="modal-dialog modal-lg" role="document" style="max-width: 80%;">
		<div class="modal-content">

			<div class="text-center modal-header">
				<h3 class="w-100 modal-title">Búsqueda de Empleados</h3>
				<button type="button" class="close" data-dismiss="modal" title="Cerrar">
					<i class="fa fa-window-close fa-2x text-primary"></i>
				</button>
			</div>

			<div class="modal-body">
				 <div id="div_contenedor"></div>
			</div>

		</div>
	</div>
</div>



<script src="../../view/profesional/js/profesional.js?v="<?=rand();?>></script>