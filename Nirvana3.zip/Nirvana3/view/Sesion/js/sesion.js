$(document).ready(function () {
	$(document).on("click", "#VerMostrarContrasena", function () {
		let inputPassword = $(this).parent().find("input");
		if ($(inputPassword).val() != "") {
			if ($(inputPassword).prop("type") == "password") {
				$(inputPassword).prop("type", "text");
				$(this).html('<i class="fa fa-eye-slash"></i>');
			}else if($(inputPassword).prop("type") == "text"){
				$(inputPassword).prop("type", "password");
				$(this).html('<i class="fa fa-eye"></i>');
			}
		}
	});
	
	$(document).on("submit", "#frmSesion", function (event) {
		event.preventDefault();

		$.ajax({
	        url: $(this).prop("action"),
	        method: $(this).attr("method"),
	        data: new FormData(event.target),
	        dataType: "json",
	        processData: false,
	        contentType: false
	    }).done((res) => {
			if(res.tipoRespuesta == "success"){
				window.location.href = res.url;
			} else {
				alertify.notify(res.mensaje, res.tipoRespuesta, 4);
			}
	    });
	});

	$(document).on("click", "#btnCerrarSesion", function (event) {
		event.preventDefault();

		alertify.confirm("Esta segur(a) que desea cerrar sesión?", () => {
			$.ajax({
				url: $(this).attr("href"),
				method: "post",
				dataType: "json"
			}).done((res) => {
				if (res.tipoRespuesta) {
					window.location.href = res.url
				}
			});
		}).set("labels", { 
			ok: "Sí", 
			cancel: "No"
		});
	});

});