<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Favicon: Logo Ingesotfware -->
    <link rel="shortcut icon" href="../../public/img/favicon/favicon.ico" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/vendor/fonts/circular-std/style.css">
    <link rel="stylesheet" href="../../assets/libs/css/style.min.css?v="<?=rand();?>>
    <link rel="stylesheet" href="../../assets/vendor/fonts/fontawesome/css/all.min.css">
    <!-- Alertify CSS 1.12.0 -->
    <link rel="stylesheet" href="../../assets/vendor/alertify/css/alertify.min.css?v="<?=rand();?>>
    <!-- Default theme -->
    <link rel="stylesheet" href="../../assets/vendor/alertify/css/themes/default.min.css?v="<?=rand();?>>
    <title>Nirvana</title>
</head>

<body>
    <!-- ============================================================== -->
    <!-- login page  -->
    <!-- ============================================================== -->
    <div class="splash-container">
        <div class="card">
            <div class="card-header text-center">
                <a href="<?=getUrl("sesion", "sesion", "vistaInicioSesion", false, "ajax");?>">
                    <img class="logo-img" src="../../assets/images/logo.png" alt="logo">
                </a>
                <span class="splash-description">Por favor ingrese su información de usuario.</span>
            </div>
            <div class="card-body">
                <form id="frmSesion" method="post" action="<?=getUrl("sesion", "sesion", "iniciarSesion", false, "ajax");?>" autocomplete="off">
                    <div class="form-group">
                        <input type="text" name="usuario" id="usuario" class="form-control form-control-lg" placeholder="Usuario" required>
                    </div>
                    <div class="input-group form-group">
                        <input type="password" name="contrasena" id="contrasena" class="form-control" placeholder="Contraseña" required>
                        <button type="button" class="btn btn-outline-primary" id="VerMostrarContrasena">
                            <i class="fa fa-eye"></i>
                        </button>
                    </div>
                    <div class="form-group">
                        <label class="custom-control custom-checkbox">
                            <input class="custom-control-input" type="checkbox">
                            <span class="custom-control-label">Recordarme</span>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg btn-block">Ingresar</button>
                </form>
            </div>
            <div class="text-center card-footer bg-white p-0">
                <div class="card-footer-item card-footer-item-bordered">
                    <a href="javascript:void(0)" class="footer-link">Olvido su contraseña?</a>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================== -->
    <!-- end login page  -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    
    <!-- jQuery 3.4.1 -->
    <script src="../../assets/vendor/jquery/jquery.min.js"></script>
    <!-- Sesion Js -->
    <script src="../../views/sesion/js/sesion.js?v="<?=rand();?>></script>
    <!-- Alertify JS -->
<script src="../../assets/vendor/alertify/js/alertify.min.js?v="<?=rand();?>></script>
</body>

</html>