<form id="frmCrearEmpleado" method="post" enctype="multipart/form-data" action="<?=getUrl("empleado", "empleado", "registrarEmpleado", false, "ajax"); ?>" autocomplete="off">
	<div class="row">
		<div class="col-12">
			<div class="page-header">
				
				<div class="pb-3 align-items-center row">
					<div class="col-4">
						<h2 class="pageheader-title">Empleados</h2>
					</div>
					
					<div class="col-6">
						<a href="<?=getUrl("Empleado", "Empleado", "vistaCrearEmpleado");?>" class="btn btn-primary" title="Nuevo Empleado">
							<i class="fa fa-file"></i>
						</a>

						<button type="submit" class="btn btn-primary" title="Guardar Empleado">
							<i class="fa fa-save"></i>
						</button>

						<button type="button" class="btn btn-primary" id="buscarEmpleados" title="Buscar Empleados">
							<i class="fa fa-search"></i>
						</button>
					</div>
				</div>

				<div class="page-breadcrumb">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="javascript:void(0)" class="breadcrumb-link">Archivos</a></li>
							<li class="breadcrumb-item active" aria-current="page">Empleados</li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
	</div>
	
	
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
			<div class="card">
				<div class="card-body">
					<div class="mt-4 row">
						<div class="col-12">

							<div class="card">
								<div class="card-header">
									<ul class="nav nav-tabs">
										<li class="nav-item">
											<a class="nav-link active" data-toggle="tab" href="#datos_basicos" role="tab">
												<i class="fa fa-edit"></i>
												<b>Datos Básicos</b>
											</a>
										</li>
										<li class="nav-item">
											<a class="nav-link" data-toggle="tab" href="#seguridad_social" role="tab">
												<i class="fa fa-heartbeat"></i>
												<b>Seguridad Social</b>
											</a>
										</li>
									</ul>
								</div>

								<div class="card-block">
									<div class="tab-content">
										<div class="tab-pane active" id="datos_basicos">
											<div class="container-fluid">
												<div class="row">
													<div class="col-9">
														<div class="row">
															<div class="col-5">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Nit_Empresa">Sede&nbsp;*</label>
																		<select name="Nit_Empresa" class="form-control select2" required>
																			<option value="">Seleccione ...</option>
																			<?php foreach ($sedes as $sede): ?>
																			<option value="<?=$sede["nit_Empresa"];?>"><?=$sede["nombre"];?></option>
																			<?php endforeach; ?>
																		</select>
																	</div>
																</div>
															</div>

															<div class="col-4">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="ti_sigla">Tipo&nbsp;de&nbsp;Identidad&nbsp;*</label>
																		<select name="ti_sigla" class="form-control select2" required>
																			<option value="">Seleccione ...</option>
																			<?php foreach ($tiposIdentificacion as $tipoIdentificacion): ?>
																			<option value="<?=$tipoIdentificacion["ti_sigla"];?>"><?=$tipoIdentificacion["ti_descripcion"];?></option>
																			<?php endforeach; ?>
																		</select>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Cedula_Empleado">No.&nbsp;de&nbsp;Identificación&nbsp;*</label>
																		<input type="text" name="Cedula_Empleado" id="Cedula_Empleado" class="form-control number" required>
																	</div>
																</div>
															</div>
														</div>

														<div class="row">
															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Nombres">Nombres&nbsp;*</label>
																		<input type="text" name="Nombres" id="Nombres" class="form-control" required>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Apellido1">Primer&nbsp;Apellido&nbsp;*</label>
																		<input type="text" name="Apellido1" id="Apellido1" class="form-control" required>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Apellido2">Segundo&nbsp;Apellido&nbsp;*</label>
																		<input type="text" name="Apellido2" id="Apellido2" class="form-control" required>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="sexo">Genéro&nbsp;*</label>
																		<select name="sexo" class="form-control select2" required>
																			<option value="">Seleccione </option>
																			<option value="F">Femenino </option>
																			<option value="M">Masculino </option>
																		</select>
																	</div>
																</div>
															</div>
														</div>

														<div class="row">
															<div class="col-6">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Direccion">Dirección&nbsp;*</label>
																		<input type="text" name="Direccion" id="Direccion" class="form-control" required>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Fecha_Nacido">Fecha&nbsp;de&nbsp;Nacimiento</label>
																		<input type="date" name="Fecha_Nacido" id="Fecha_Nacido" class="form-control">
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="LugarNacimiento">Lugar&nbsp;de&nbsp;Nacimiento&nbsp;*</label>
																		<select name="LugarNacimiento" class="form-control select2" required>
																			<option value="">Seleccione </option>
																			<?php foreach ($ciudades as $ciudad): ?>
																			<option value="<?=$ciudad["Codigo_Ciudad"];?>"><?=$ciudad["Nombre"];?></option>
																			<?php endforeach; ?>
																		</select>
																	</div>
																</div>
															</div>
														</div>

														<div class="row">
															<div class="col-4">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="CiudadResidencia">Ciudad&nbsp;de&nbsp;Residencia&nbsp;*</label>
																		<select name="CiudadResidencia" class="form-control select2" required>
																			<option value="">Seleccione </option>
																			<?php foreach ($ciudades as $ciudad): ?>
																			<option value="<?=$ciudad["Codigo_Ciudad"];?>"><?=$ciudad["Nombre"];?></option>
																			<?php endforeach; ?>
																		</select>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Salario_Basico">Salario&nbsp;Básico&nbsp;*</label>
																		<input type="text" name="Salario_Basico" id="Salario_Basico" class="form-control format" required>
																	</div>
																</div>
															</div>

															<div class="col-5">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Cargo">Cargo&nbsp;*</label>
																		<select name="Cargo" class="form-control select2" required>
																			<option value="">Seleccione </option>
																			<?php foreach ($cargos as $cargo): ?>
																			<option value="<?=$cargo["Codigo_Cargo"];?>"><?=$cargo["Descripcion"];?></option>
																			<?php endforeach; ?>
																		</select>
																	</div>
																</div>
															</div>
														</div>

														<div class="row">
															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Telefono">Teléfono&nbsp;1&nbsp;*</label>
																		<input type="text" name="Telefono" id="Telefono" class="form-control number" required>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Telefono_2">Teléfono&nbsp;2</label>
																		<input type="text" name="Telefono_2" id="Telefono_2" class="form-control number" required>
																	</div>
																</div>
															</div>

															<div class="col-5">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Email">Email&nbsp;Personal&nbsp;*</label>
																		<input type="email" name="Email" id="Email" class="form-control" required>
																	</div>
																</div>
															</div>												
														</div>

														<div class="row">
															<div class="col-5">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Email_Corporativo">Email&nbsp;Corporativo</label>
																		<input type="text" name="Email_Corporativo" id="Email_Corporativo" class="form-control" required>
																	</div>
																</div>
															</div>

															<div class="col-4">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Tipo_Ingreso">Tipo&nbsp;de&nbsp;Vinculación&nbsp;*</label>
																		<select name="Tipo_Ingreso" class="form-control select2">
																			<option value="">Seleccione </option>
																			<?php foreach ($tiposVinculacion as $tipoVinculacion): ?>
																			<option value="<?=$tipoVinculacion["Codigo"];?>"><?=$tipoVinculacion["Descripcion"];?></option>
																			<?php endforeach; ?>
																		</select>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Fecha_Ingreso">Fecha&nbsp;de&nbsp;Ingreso</label>
																		<input type="date" name="Fecha_Ingreso" id="Fecha_Ingreso" class="form-control">
																	</div>
																</div>
															</div>
														</div>
													</div>

													<div class="col-3">
														<div class="pt-3 row">
															<div class="col-12">
																<div class="row">
																	<div class="text-center col-12">
																		<div class="font-weight-bold" style="font-size: 18px;">Edad: <span id="EdadEmpleado"></span></div>
																	</div>
																</div>
																<div class="row">
																	<div class="text-center col-12">
																		<div class="row">
																			<div class="col-12">
																				<label for="per_img" style="cursor: pointer;">
																					<i class="border border-dark btn btn-outline-white" title="Subir imagen">
																						<img class="img-fluid" src="../../public/img/svg/upload-user.svg" alt="upload-user">
																					</i>
																				</label>
																			</div>
																			<div class="text-center col-12">
																				<div class="nombreArchivo"></div>
																				<div class="ContenedorPrevisualizarArchivo"></div>
																				<input type="file" class="subirArchivo" name="per_img" id="per_img" accept="image/png, image/jpeg" style="display: none;">
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>

										<div class="tab-pane" id="seguridad_social">
											<div class="container-fluid">
												<div class="row">
													<div class="col-12">
														<div class="row">
															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Nit_Eps">EPS</label>
																		<select name="Nit_Eps" id="Nit_Eps" class="form-control select2">
																			<option value="">Seleccione ...</option>
																			<?php foreach ($entidadesSegSocial as $entidadSegSocial): ?>
																			<?php if ($entidadSegSocial["Tipo"] == "1"): ?>
																			<option value="<?=$entidadSegSocial["Nit"];?>"><?=$entidadSegSocial["Nombre"];?></option>
																			<?php endif; ?>
																			<?php endforeach;?>
																		</select>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Nit_Fp">Fondo&nbsp;de&nbsp;Pensiones</label>
																		<select name="Nit_Fp" id="Nit_Fp" class="form-control select2">
																			<option value="">Seleccione ...</option>
																			<?php foreach ($entidadesSegSocial as $entidadSegSocial): ?>
																			<?php if ($entidadSegSocial["Tipo"] == "2"): ?>
																			<option value="<?=$entidadSegSocial["Nit"];?>"><?=$entidadSegSocial["Nombre"];?></option>
																			<?php endif; ?>
																			<?php endforeach;?>
																		</select>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Nit_Fc">Fondo&nbsp;de&nbsp;Cesantías</label>
																		<select name="Nit_Fc" id="Nit_Fc" class="form-control select2">
																			<option value="">Seleccione ...</option>
																			<?php foreach ($entidadesSegSocial as $entidadSegSocial): ?>
																			<?php if ($entidadSegSocial["Tipo"] == "5"): ?>
																			<option value="<?=$entidadSegSocial["Nit"];?>"><?=$entidadSegSocial["Nombre"];?></option>
																			<?php endif; ?>
																			<?php endforeach;?>
																		</select>
																	</div>
																</div>
															</div>

															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Nit_Arl">ARL</label>
																		<select name="Nit_Arl" id="Nit_Arl" class="form-control select2">
																			<option value="">Seleccione ...</option>
																			<?php foreach ($entidadesSegSocial as $entidadSegSocial): ?>
																			<?php if ($entidadSegSocial["Tipo"] == "3"): ?>
																			<option value="<?=$entidadSegSocial["Nit"];?>"><?=$entidadSegSocial["Nombre"];?></option>
																			<?php endif; ?>
																			<?php endforeach;?>
																		</select>
																	</div>
																</div>
															</div>
														</div>

														<div class="row">
															<div class="col-3">
																<div class="form-group row">
																	<div class="col-12">
																		<label for="Nit_Cc">Caja&nbsp;de&nbsp;Compensación</label>
																		<select name="Nit_Cc" id="Nit_Cc" class="form-control select2">
																			<option value="">Seleccione ...</option>
																			<?php foreach ($entidadesSegSocial as $entidadSegSocial): ?>
																			<?php if ($entidadSegSocial["Tipo"] == "4"): ?>
																			<option value="<?=$entidadSegSocial["Nit"];?>"><?=$entidadSegSocial["Nombre"];?></option>
																			<?php endif; ?>
																			<?php endforeach;?>
																		</select>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>
</form>

<!-- MODAL BUSCAR EMPLEADO-->
<div class="modal fade" id="modalBuscarEmpleados">
	<div class="modal-dialog modal-lg" role="document" style="max-width: 80%;">
		<div class="modal-content">

			<div class="text-center modal-header">
				<h3 class="w-100 modal-title">Búsqueda de Empleados</h3>
				<button type="button" class="close" data-dismiss="modal" title="Cerrar">
					<i class="fa fa-window-close fa-2x text-primary"></i>
				</button>
			</div>

			<div class="modal-body">

			</div>

		</div>
	</div>
</div>

<!-- MODAL BUSCAR NOVEDADES-->
<div class="modal fade" id="modalBuscarNovedades">
	<div class="modal-dialog modal-lg" role="document" style="max-width: 80%;">
		<div class="modal-content">

			<div class="text-center modal-header">
				<h3 class="w-100 modal-title">Búsqueda de Novedades Empleado</h3>
				<button type="button" class="close" data-dismiss="modal" title="Cerrar">
					<i class="fa fa-window-close fa-2x text-primary"></i>
				</button>
			</div>

			<div class="modal-body">

			</div>

		</div>
	</div>
</div>

<!-- MODAL PREVISUALIZAR ARCHIVO -->
<div class="modal fade" id="modalPrevisualizarArchivo">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="text-center col-12">
							<img src="" alt="" title="" height="400" width="500" id="previsualizarImagenModal" style="display: none;">
							<iframe src="" height="400" width="500" id="previsualizarArchivoModal" style="display: none;"></iframe>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="../../views/empleado/js/empleado.js?v="<?=rand();?>></script>