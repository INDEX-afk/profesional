$(document).ready(function () {

    // SCRIPT CALCULAR EDAD
	function calcularEdad(fecha) {
		var hoy = new Date();
		var cumpleanos = new Date(fecha);
		var edad = hoy.getFullYear() - cumpleanos.getFullYear();
		var m = hoy.getMonth() - cumpleanos.getMonth();

		if (m < 0 || (m === 0 && hoy.getDate() < cumpleanos.getDate())) {
			edad--;
		}

		return edad;
	}

	$("#Fecha_Nacido").each(function () {
		if (calcularEdad($(this).val())) {
			$("#EdadEmpleado").text(calcularEdad($(this).val()) + " Años");
		}
		$(document).on("change", "#Fecha_Nacido", function () {
			if (calcularEdad($(this).val())) {
				$("#EdadEmpleado").text(calcularEdad($(this).val()) + " Años");
			}
		});
    });
    
    // $(function ValidarCedulaEmpleado(){
	// 	$(document).on("keyup", "#Cedula_Empleado", function () {
	// 		$.ajax({
	// 			url: "ajax.php?modulo=empleado&controlador=empleado&funcion=ValidarCedulaEmpleado",
	// 			method: "post",
	// 			dataType: "json",
	// 			data: {
	// 				Cedula_Empleado: $(this).val(),
	// 			},
	// 		}).done((res) => {
	// 			if (res === true) {
	// 				$(this)[0].setCustomValidity("Esa cédula ya existe");
	// 			} else {
	// 				$(this)[0].setCustomValidity("");
	// 			}
	// 		});
	// 	});
    // });
    
    // REGISTRAR EMPLEADO
	$(document).on("submit", "#frmCrearEmpleado", function (event) {
	    event.preventDefault();
	    $(this).find("button[type=submit]").prop("disabled", true);

	    $.ajax({
	        url: $(this).prop("action"),
	        method: $(this).attr("method"),
	        data: new FormData(event.target),
	        dataType: "json",
	        processData: false,
	        contentType: false
	    }).done((res) => {
	        alertify.notify(res.mensaje, res.tipoRespuesta, 4, () => {
	            console.log(res);
	        });
	    });

	    setTimeout(() => {
	        $(this).find("button[type=submit]").prop("disabled", false);
	    }, 500);
	});

	// EDITAR EMPLEADO
	$(document).on("submit", "#frmEditarEmpleado", function (event) {
	    event.preventDefault();
	    $(this).find("button[type=submit]").prop("disabled", true);

	    $.ajax({
	        url: $(this).prop("action"),
	        method: $(this).attr("method"),
	        data: new FormData(event.target),
	        dataType: "json",
	        processData: false,
	        contentType: false
	    }).done((res) => {
	        alertify.notify(res.mensaje, res.tipoRespuesta, 4, () => {
	            console.log(res);
	        });
	    });

	    setTimeout(() => {
	        $(this).find("button[type=submit]").prop("disabled", false);
	    }, 500);
	});

    /***************************LISTAR EMPLEADOS**************************/

	/****ABRIR MODAL BUSCAR EMPLEADO**/
	$(document).on("click", "#buscarEmpleados", function () {
		$.ajax({
			url: "ajax.php?modulo=empleado&controlador=empleado&funcion=modalBuscarEmpleado",
		}).done((res) => {
			$("#modalBuscarEmpleados .modal-body").html(res);
			$("#modalBuscarEmpleados").modal({
				backdrop: "static",
				keyboard: false
			});
		});
	});

	$(document).on("click", "#btnNuevaBusqueda", function () {
		$(".nuevaBusqueda").hide();
		$("#menu-ir-a-empleados").hide();
		$("#frm_ModalBuscarEmpleados")[0].reset();
	});

	/********* LISTAR EMPLEADO**************/
	$(function listarEmpleados() {

		$(document).on("submit", "#frm_ModalBuscarEmpleados", function (event) {

			event.preventDefault();

			if ($("#cedula").val() || $("#nombre").val() || $("#cargo").val() || $("#estado").val()) {

				$("#containerTablaModalBuscarEmpleados").show();
				$("#menu-ir-a-empleados").hide();

				var tablaModalBuscarEmpleados = $("#tablaModalBuscarEmpleados").DataTable({
					dom: "Bfrtip",
					buttons: [{
                        attr: { "class": "mr-4 btn btn-success", "title": "Exportar a Excel" },
                        text: '<i class="fa fa-file-excel"></i>',
                        extend: "excelHtml5",
                        filename: "Empleados",
                        sheetName: "Empleados",
                    }],
					language: {
						"url": "../../assets/vendor/datatables/language/datatablesSpanish.json"
					},
					destroy: true,
					pageLength: 10,
					autoWidth: true,
					lengthChange: false,
					columnDefs: [{
						"className": "text-center",
						"targets": "_all"
					}],
					ajax: {
						url: $(this).prop("action"),
						method: $(this).prop("method"),
						data: {
							"cedula": $("#cedula").val(),
							"nombre": $("#nombre").val(),
							"cargo": $("#cargo").val(),
							"estado": $("#estado").val()
						},
					},
					columns: [
						{ data: "cedula" },
						{ data: "nombre" },
						{ data: "cargo" },
						{ data: "estado" }
					],
				});

				$(document).on("click", "#tablaModalBuscarEmpleados button", function () {
					let data = $("#tablaModalBuscarEmpleados").DataTable().row($(this).parents("tr")).data();

					$("#menu-ir-a-empleados").hide();
					$("#menu-ir-a-empleados").show(500);

					let pagina = "index.php";
					let cedula = "&cedula=" + $(data.cedula).text();
					let nit_sede = "&nit_sede=" + data.nit_sede;
					let modulo = "?modulo=empleado";
					let controlador = "&controlador=empleado";

					$("#btnVerEmpleado").on("click", function () {
						let funcion = "&funcion=vistaVerEmpleado";
						let parametros = cedula + nit_sede;
						let url = pagina + modulo + controlador + funcion + parametros;
						$(this).attr("href", url);
					});

					$("#btnEditarEmpleado").on("click", function () {
						let funcion = "&funcion=vistaEditarEmpleado";
						let parametros = cedula + nit_sede;
						let url = pagina + modulo + controlador + funcion + parametros;
						$(this).attr("href", url);
					});
				});

			} else {
				swal({
					type: "warning",
					title: "Seleccione un criterio de búsqueda"
				});
			}
		});
	});

	/***************************LISTAR NOVEDADES**************************/

	/********* LISTAR NOVEDADES EMPLEADO**************/
	$(function listarNovedadesEmpleado() {
		$(document).on("shown.bs.tab", "a[data-toggle=tab]", function () {
			let pestana = $(this).attr("href");

			if (pestana == "#historial") {
				let columnDefs = [];

				if ($("#cedula_empleado").val()) {
					columnDefs = [
						{"className": "text-center","targets": "_all"}
					];
				} else {
					columnDefs = [
						{"className": "d-none", "targets": [5]},
						{"className": "text-center", "targets": [0, 1, 2, 3, 4]},
					];
				}

				$("#containerTablaModalBuscarNovedadesEmpleado").show();

				var tablaModalBuscarNovedadesEmpleado = $("#tablaModalBuscarNovedadesEmpleado").DataTable({
					dom: "Bfrtip",
					buttons: [{
                        attr: { "class": "mr-4 btn btn-success", "title": "Exportar a Excel" },
                        text: '<i class="fa fa-file-excel"></i>',
                        extend: "excelHtml5",
                        filename: "Novedades Empleado",
                        sheetName: "Novedades Empleado",
                    }],
					language: {
						"url": "../../assets/vendor/datatables/language/datatablesSpanish.json"
					},
					destroy: true,
					pageLength: 10,
					autoWidth: true,
					lengthChange: false,
					columnDefs: columnDefs,
					ajax: {
						url: "ajax.php?modulo=empleado&controlador=empleado&funcion=listarNovedadesEmpleado",
						method: "post",
						data: {
							"cedula": $("#cedula_empleado").val() ? $("#cedula_empleado").val() : $("#Cedula_Empleado").val(),
							"fecha_desde": "",
							"fecha_hasta": "",
							"tipo_novedad": ""
						},
					},
					columns: [
						{ data: "cedula", width: "15%" },
						{ data: "fecha", width: "15%" },
						{ data: "novedad", width: "15%" },
						{ data: "observaciones" },
						{ data: "estado", width: "10%" },
						{ data: "eliminar", width: "10%" }
					]
				});
			}

		});
	});

});