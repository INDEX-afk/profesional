<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<!-- Favicon: Logo Ingesotfware -->
<link rel="shortcut icon" href="../../public/img/favicon/favicon.ico" type="image/x-icon">
<!-- Bootstrap CSS 4.3.1 -->
<link rel="stylesheet" href="../../assets/vendor/bootstrap/css/bootstrap.min.css?v="<?=rand();?>>
<link rel="stylesheet" href="../../assets/vendor/fonts/circular-std/style.css?v="<?=rand();?>>
<link rel="stylesheet" href="../../assets/libs/css/style.min.css?v="<?=rand();?>>
<!-- Datatables CSS -->
<link href="../../assets/vendor/datatables/css/datatables.min.css" rel="stylesheet">
<!-- Icons Fontawesome -->
<link rel="stylesheet" href="../../assets/vendor/fonts/fontawesome/css/all.min.css">
<!-- Select2 CSS -->
<link href="../../assets/vendor/select2/css/select2.min.css?v=<?=rand(); ?>" rel="stylesheet">
<!-- Select2 Bootstrap Theme -->
<link href="../../assets/vendor/select2/css/select2-bootstrap.min.css?v=<?=rand(); ?>" rel="stylesheet">
<!-- Alertify CSS 1.12.0 -->
<link rel="stylesheet" href="../../assets/vendor/alertify/css/alertify.min.css?v="<?=rand();?>>
<!-- Default theme -->
<link rel="stylesheet" href="../../assets/vendor/alertify/css/themes/default.min.css?v="<?=rand();?>>
<title>Nirvana</title>