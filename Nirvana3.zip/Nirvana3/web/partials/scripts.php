<script src="../../assets/vendor/jquery/jquery.min.js"></script>
<!-- bootstap bundle js -->
<script src="../../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<!-- slimscroll js -->
<script src="../../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
<!-- main js -->
<script src="../../assets/libs/js/main-js.js"></script>
<!-- Datatables JS -->
<script src="../../assets/vendor/datatables/js/datatables.min.js"></script>
<!-- Crypto Js -> JavaScript library of crypto standards.. -->
<script src="../../assets/vendor/crypto-js/js/crypto-js.min.js"></script>
<!-- Cleave Js -> Format your <input/> content when you are typing. -->
<script src="../../assets/vendor/cleave/cleave.min.js"></script>
<!-- Select2 JS -->
<script src="../../assets/vendor/select2/js/select2.full.min.js"></script>
<!-- Select2 Language -->
<script src="../../assets/vendor/select2/language/es.min.js"></script>
<!-- Alertify JS -->
<script src="../../assets/vendor/alertify/js/alertify.min.js?v="<?=rand();?>></script>
<!-- Scripts Generales -->
<script src="../../public/js/scripts.js?v="<?=rand();?>></script>