<!-- Pie de página -->
<div class="row d-none d-md-block">
    <footer class="footer fixed-bottom footer-dark navbar-border">
        <div class="col-12 clearfix blue-grey lighten-2 text-sm-center mb-0 px-2">
            <div class="row">
                <div class="col-3 text-md-left d-block d-md-inline-block">
                    <span>Copyright &copy; <?=date("Y"); ?></span>
                </div>
            </div>
        </div>
    </footer>