<?php
include_once "../../app/lib/helpers.php";
@session_start();

echo cargarPrincipal();
?>