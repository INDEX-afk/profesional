<?php include_once "../../app/lib/helpers.php";?>
<!DOCTYPE html>
<html lang="es">
<head>
	<!-- jQuery 3.4.1 -->
	<script src="../../assets/vendor/jquery/jquery.min.js"></script>
	<?php include_once "../../web/partials/head.php";?>
</head>
<body>
	<div class="dashboard-main-wrapper">
		<!-- HEADER -->
		<header class="dashboard-header">
          <?php include_once "../../web/partials/header.php";?>
		</header>
		<!-- MENÚ -->
		<?php include_once "../../web/partials/menu.php";?>
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content">
					<?=cargarPrincipal();?>
                </div>
            </div>
        </div>
	</div>
	<!-- FOOTER -->
	<footer>
		<?php include_once "../../web/partials/footer.php";?>
	</footer>
	<!-- SCRIPTS -->
	<div id="scripts">
        <?php include_once "../../web/partials/scripts.php";?>
      </div>
</body>
</html>