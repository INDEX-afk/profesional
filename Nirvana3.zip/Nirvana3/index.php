<?php
	include_once "app/lib/helpers.php";
	header("Location: " . "web/pages/" . getUrl("sesion", "sesion", "vistaInicioSesion", false, "ajax"));
?>