<<?php
include_once'../../app/model/MasterModel.php';
class CargoModel extends MasterModel{
   
}
