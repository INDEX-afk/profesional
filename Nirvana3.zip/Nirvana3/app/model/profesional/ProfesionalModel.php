<?php
include_once'../../app/model/MasterModel.php';
class ProfesionalModel extends MasterModel{
   
}
