<?php
include_once('../../app/Model/MasterModel/MasterModel.php');

	class ProfesionesModel extends MasterModel{
	
	}
?>