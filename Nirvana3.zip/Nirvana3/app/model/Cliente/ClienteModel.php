<?php
include_once'../../app/model/MasterModel.php';
class ClienteModel extends MasterModel{
   
}
