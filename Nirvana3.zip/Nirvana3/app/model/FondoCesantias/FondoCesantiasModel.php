<?php
include_once('../../app/Model/MasterModel/MasterModel.php');

	class FondoCesantiasModel extends MasterModel{
	
	}
?>