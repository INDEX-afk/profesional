<?php
include_once('../../app/Model/MasterModel/MasterModel.php');

	class EstadosCivilesModel extends MasterModel{
	
	}
?>