<?php
@session_start();

function redirect($url) {
    echo "
        <script type='text/javascript'>
                window.location.href='$url';
        </script>";
}

function dd($var) {
    echo "<pre>";
    die(print_r($var));
}

function getUrl($modulo, $controlador, $funcion, $parametros = false, $ajax = false) {

    if ($ajax) {
        $pagina = "ajax";
    } else {
        $pagina = "index";
    }

    $url = "$pagina.php?modulo=$modulo&controlador=$controlador&funcion=$funcion";

    if ($parametros) {
        foreach ($parametros as $indice => $valor) {
            $url .= "&$indice=$valor";
        }
    }

    return $url;
}

function cargarPrincipal() {

    if (!isset($_GET["modulo"]) and !isset($_GET["controlador"]) and !isset($_GET["funcion"])) {
        include_once "../../web/partials/dashboard.php";
    } else {
        $modulo = $_GET["modulo"];
        $controlador = $_GET["controlador"];
        $funcion = $_GET["funcion"];
        if (is_dir("../../app/Controller/$modulo")) {

            if (file_exists("../../app/controller/$modulo/" . $controlador . "Controller.php")) {
                include_once "../../app/controller/$modulo/" . $controlador . "Controller.php";
                $nombreClase = $controlador . "Controller";
                $objClase = new $nombreClase();
                if (method_exists($objClase, $funcion)) {
                    $objClase->$funcion();
                } else {
                    echo "La función especificada no existe";
                }
            } else {
                echo "El controlador especificado no existe";
            }

        } else {
            echo "El módulo especificado no existe";
        }
    }
}

function encriptar($value, $passphrase = "") {
    $salt = openssl_random_pseudo_bytes(8);
    $salted = '';
    $dx = '';
    while (strlen($salted) < 48) {
        $dx = md5($dx . $passphrase . $salt, true);
        $salted .= $dx;
    }
    $key = substr($salted, 0, 32);
    $iv = substr($salted, 32, 16);
    $encrypted_data = openssl_encrypt(json_encode($value), "aes-256-cbc", $key, true, $iv);
    $data = array("ct" => base64_encode($encrypted_data), "iv" => bin2hex($iv), "s" => bin2hex($salt));

    return htmlspecialchars(json_encode($data));
}

function decriptar($jsonString, $passphrase = "") {
    $jsondata = json_decode($jsonString, true);
    $salt = hex2bin($jsondata["s"]);
    $ct = base64_decode($jsondata["ct"]);
    $iv = hex2bin($jsondata["iv"]);
    $concatedPassphrase = $passphrase . $salt;
    $md5 = array();
    $md5[0] = md5($concatedPassphrase, true);
    $result = $md5[0];
    for ($i = 1; $i < 3; $i++) {
        $md5[$i] = md5($md5[$i - 1] . $concatedPassphrase, true);
        $result .= $md5[$i];
    }
    $key = substr($result, 0, 32);
    $data = openssl_decrypt($ct, "aes-256-cbc", $key, true, $iv);

    return json_decode($data, true);
}

function comprobarCaracteresEspeciales($cadena) {
    if (preg_match("/^[a-zA-Z0-9\-_@. ]{1,70}$/", $cadena)) {
        return true;
    } else {
        return false;
    }
}

function alertas($mensaje) {
    echo "<script type='text/javascript'>
		alert('$mensaje');
	</script>";
}