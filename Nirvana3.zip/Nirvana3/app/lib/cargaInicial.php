<?php
include_once '../lib/conf/Connection.php';

$objConexion= new Connection();

$conexion=$objConexion->getConnect();

$sqlHorizontal="select * from menu where men_tip_id=1 order by men_parent,men_orden,men_display";
$sqlGeneral="select * from menu where men_tip_id=2 order by men_parent,men_orden,men_display";

$menuHorizontal=mysqli_query($conexion,$sqlHorizontal);

$menuGeneral=mysqli_query($conexion,$sqlGeneral);

$horizontal=generarMenu($menuHorizontal);
$general=generarMenu($menuGeneral);

function generarMenu($menuHorizontal){

    $respuesta=array();
    foreach($menuHorizontal as $ind=>$menuH){
        if($menuH['men_parent']!=""){
            if(isset($respuesta[$menuH['men_parent']])){
                $respuesta[$menuH['men_parent']]['child'][$menuH['men_id']]=$menuH;
            }
            else{
                $copiaRes=$respuesta;
                foreach($copiaRes as $indice => $valor){
                    if(isset($valor['child'])){
                        if(isset($valor['child'][$menuH['men_parent']])){
                            $respuesta[$indice]['child'][$menuH['men_parent']]['child'][$menuH['men_id']]=$menuH;
                        }
                    }
                }
            }
            
        }
        else{
            $respuesta[$menuH['men_id']]=$menuH;
        }
        
    }

    return $respuesta;

}

/* Lo deshabilito para probar si desde el controller Home Funciona */
$sqlDepto="select * from departamento order by dep_nombre";
$sqlCiudad="select * from ciudad order by ciu_nombre";

$deptos=mysqli_query($conexion,$sqlDepto);

$ciudades=mysqli_query($conexion,$sqlCiudad);

   $tipos= mysqli_query($conexion, "select * from pqrs_tipo order by pqr_tip_descripcion");

?>