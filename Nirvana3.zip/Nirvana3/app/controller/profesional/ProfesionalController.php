<?php
include_once'../../app/model/profesional/ProfesionalModel.php';

class ProfesionalController extends ProfesionalModel{
	public function VistaCrearProfesional(){
		
		$tiposId=$this->consultar("ti_sigla, ti_descripcion", "tipo_id", " ti_estado='A'", "order by ti_descripcion");			
		$ciudades=$this->consultar("Codigo_Ciudad, Nombre", "ciudades", "", "order by nombre");		
	
                $this->closeConnect();
		include_once'../../view/profesional/GuiCrearProfesional.php';
	}
	
	
	
	public function RegistrarProfesional(){
            
		extract($_POST);
                
		
		$pers=$this->consultar("*","profesionales_salud"," estado='A' and identificacion='$identificacion'");
		if($pers->num_rows >0)
		{
			alertas("El profesional ya existe !!");
		}
		else
		{
                   
                           
                            $this->insertar("profesionales_salud",
                                "identificacion,no_registro, ti_sigla, nombres, apellido1, apellido2, 
                                sexo, telefono1, telefono2, celular,  ciudad, email, direccion,
                                especialidad, estado",
                                "'$identificacion','$no_registro', '$tipo_id', '$nombre', '$ape1', '$ape2', '$genero', '$tel1',
                                     '$tel2', '$celular', '$ciudad_res', '$email', '$direccion', '$especialidad', 'A'");
                            alertas("Empleado registrado con exito!!");
                    
		}
                $this->closeConnect();
                redirect(getUrl("profesional", "profesional", "VistaCrearProfesional"));
                
	}
	
        public function buscarProfesional(){
             include_once'../../view/profesional/GuiModalBuscarProfesional.php';
        }
        
	public function editarProfesional(){
            $cedula=$_GET['cedula'];
           
            $tiposId=$this->consultar("ti_sigla, ti_descripcion", "tipo_id", " ti_estado='A'", "order by ti_descripcion");		            
            $ciudades=$this->consultar("Codigo_Ciudad, Nombre", "ciudades", "", "order by nombre");	
			$profesional=$this->consultar("*", "profesionales_salud", "identificacion='$cedula'");
			$this->closeConnect();
            include_once'../../view/profesional/GuiEditarProfesional.php';
	}
        
        public function postEditarProfesional(){
            extract($_POST);
             $this->editar("profesionales_salud", 
                     " identificacion='$identificacion'", 
                     array("no_registro"=>"'$no_registro'",
						"ti_sigla"=>"'$tipo_id'",
						"nombres"=>"'$nombres'",
                         "apellido1"=>"'$ape1'",
                         "apellido2"=>"'$ape2'",
                         "sexo"=>"'$genero'",
                         "telefono1"=>"'$tel1'",                         
                         "telefono2"=>"'$tel2'",
                         "celular"=>"'$celular'",
                         "ciudad"=>"'$ciudad_res'",
                         "email"=>"'$email'",
                         "direccion"=>"'$direccion'",
                         "especialidad"=>"'$especialidad'"                       
                                                  
                        ));   
            $this->closeConnect();
            redirect(getUrl("profesional", "profesional","VistaCrearProfesional"));
        }
		
		
        
        
        
		public function verProfesional(){
            $cedula=$_GET['cedula'];
           
            $tiposId=$this->consultar("ti_sigla, ti_descripcion", "tipo_id", " ti_estado='A'", "order by ti_descripcion");		            
            $ciudades=$this->consultar("Codigo_Ciudad, Nombre", "ciudades", "", "order by nombre");	
			$profesional=$this->consultar("*", "profesionales_salud", "identificacion='$cedula'");
			$this->closeConnect();
            include_once'../../view/profesional/GuiVerProfesional.php';
	}
        
        public function postVerProfesional(){
            extract($_POST);
             $this->editar("profesionales_salud", 
                     " identificacion='$identificacion'", 
                     array("no_registro"=>"'$no_registro'",
						"ti_sigla"=>"'$tipo_id'",
						"nombres"=>"'$nombres'",
                         "apellido1"=>"'$ape1'",
                         "apellido2"=>"'$ape2'",
                         "sexo"=>"'$genero'",
                         "telefono1"=>"'$tel1'",                         
                         "telefono2"=>"'$tel2'",
                         "celular"=>"'$celular'",
                         "ciudad"=>"'$ciudad_res'",
                         "email"=>"'$email'",
                         "direccion"=>"'$direccion'",
                         "especialidad"=>"'$especialidad'"                       
                                                  
                        ));   
            $this->closeConnect();
            redirect(getUrl("profesional", "profesional","VistaCrearProfesional"));
        }
		
		
        public function ListarProfesional(){
            extract($_POST);
			$condicion="";
            $datos = array();

            $condicion="";

            if($cedula<>""){
                    $condicion = "and identificacion LIKE '%$cedula%' ";             
            }
            if($nombre<>""){
                    $condicion .= "and nombres LIKE '%$nombre%' ";             
            }
            if($especialidad<>""){
                    $condicion .= "and especialidad LIKE '%$especialidad%' ";   
            }
            if ($estado<>"" && $estado == "T") {
                    $estado = null;
            }

            $listarprofe=$this->Consultar("CONCAT(profesionales_salud.nombres,' ',profesionales_salud.apellido1, ' ', apellido2) 
                    AS Nombre_Completo ,profesionales_salud.identificacion, profesionales_salud.especialidad, profesionales_salud.estado", 
                    "profesionales_salud", " estado like '%$estado%' $condicion");
            $this->closeConnect();
           
			foreach ($listarprofe as $listarprofesional) {
                array_push($datos, 
                array(
                        "cedula" => '<a href="javascript:void(0);" class="btn">'.$listarprofesional["identificacion"].'</a>',
                        "nombre" => $listarprofesional["Nombre_Completo"],
                        "especialidad" => $listarprofesional["especialidad"],
                        "estado" => $listarprofesional["estado"],
                ));
            }

            $tabla = array("data" => $datos);

            echo json_encode($tabla);
	}
	
	public function anularProfesional(){
		extract($_POST);
        $tipoRespuesta = "error";
        $mensaje = "No se pudo eliminar el empleado, por favor consulte al administrador";
        $url = "";

		// $sqlEmpleado = "SELECT * FROM empleados WHERE Cedula_Empleado = '$Cedula_Empleado'";
		// $Empleado = $this->Consultar($sqlEmpleado);

		$this->editar("profesionales_salud", 
                     " identificacion='$identificacion'", 
                     array("estado"=>"'I'"
						                       
                                                  
                        ));

		if (mysqli_affected_rows($this->conexion) >= 0) {
			$tipoRespuesta = "success";
            $mensaje = "El registro se ha eliminado con éxito";
            $url = "";
		}

		echo json_encode(array("tipoRespuesta" => $tipoRespuesta, "mensaje" => $mensaje, "url" => $url));
	}
	
	public function validarRegistroMedico(){
		$num=$_POST['num_reg'];
		$registro=$this->consultar("no_registro","profesionales_salud", "no_registro='$num'" );
		if($registro->num_rows > 0){
			$existe=true;
		}
		else{
			$existe=false;
		}
		
		 echo json_encode($existe);
	}
}
?>