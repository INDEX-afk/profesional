<?php
include_once "../../app/model/empleado/EmpleadoModel.php";

class EmpleadoController extends EmpleadoModel {

    public function vistaCrearEmpleado() {
        $sqlTiposIdentificacion = "SELECT ti_sigla, ti_descripcion FROM tipo_id WHERE ti_estado='A' ORDER BY ti_descripcion";
        $tiposIdentificacion = $this->Consultar($sqlTiposIdentificacion);

        $sqlSedes = "SELECT nit_empresa, nombre FROM sedes ORDER BY nombre";
        $sedes = $this->Consultar($sqlSedes);

        $sqlCiudades = "SELECT Codigo_Ciudad, Nombre FROM ciudades ORDER BY nombre";
        $ciudades = $this->Consultar($sqlCiudades);

        $sqlCargos = "SELECT Codigo_Cargo, Descripcion FROM cargos ORDER BY Descripcion";
        $cargos = $this->Consultar($sqlCargos);

        $sqlEntidadesSegSocial = "SELECT * FROM entidades_seguridad_social WHERE Estado = 'A' ORDER BY Nombre";
        $entidadesSegSocial = $this->Consultar($sqlEntidadesSegSocial);

        $sqlTiposVinculacion = "SELECT * FROM tipos_vinculacion WHERE Estado = 'A' ORDER BY Descripcion";
        $tiposVinculacion = $this->Consultar($sqlTiposVinculacion);

        $this->closeConnect();

        include_once "../../views/empleado/GuiCrearEmpleado.php";
    }

    public function registrarEmpleado() {
        extract($_POST);
        extract($_FILES);
        $tipoRespuesta = "error";
        $mensaje = "No se pudo registrar el empleado, por favor colsulte al administrador";
        $url = "";
        $Ruta = "../../views/Empleados/Archivos/";

        $sqlExisteEmpleado = "SELECT * FROM empleados
        WHERE Cedula_Empleado = '$Cedula_Empleado'
        AND Estado = 'A'";
        $existeEmpleado = $this->Consultar($sqlExisteEmpleado);

        if (empty($existeEmpleado[0]["Cedula_Empleado"])) {
            if (!isset($Imagen_Empleado["name"])) {
                $Imagen_Empleado = null;
            } else {
                $Imagen_Empleado = lreplace(".", "-" . $Cedula_Empleado . ".", $Imagen_Empleado["name"]);
                $Ruta_Imagen_Empleado = $Ruta . $Imagen_Empleado;
            }
    
            $sqlEmpleado = "INSERT INTO empleados
            (Cedula_Empleado, Imagen_Empleado, Nombres, Apellido1, Apellido2, Direccion, Fecha_Nacido, Cargo, 
            Salario_Basico, Fecha_Ingreso, Telefono, Telefono_2, Tipo_Ingreso, CiudadResidencia, LugarNacimiento, 
            Email, Email_Corporativo, Nit_Eps, Nit_Fp, Nit_Fc, Nit_Arl, Nit_Cc, ti_sigla, sexo, Estado, Nit_Empresa)
            VALUES ('$Cedula_Empleado', '$Imagen_Empleado', '$Nombres', '$Apellido1', '$Apellido2', '$Direccion', '$Fecha_Nacido', '$Cargo', 
            '" . str_replace(",", "", $Salario_Basico) . "', '$Fecha_Ingreso', '$Telefono', '$Telefono_2', '$Tipo_Ingreso', '$CiudadResidencia',
            '$LugarNacimiento', '$Email', '$Email_Corporativo', '$Nit_Eps', '$Nit_Fp', '$Nit_Fc', '$Nit_Arl', '$Nit_Cc', '$ti_sigla', '$sexo', 'A', '$Nit_Empresa')";
            $this->Insertar($sqlEmpleado);
    
            if (mysqli_affected_rows($this->conexion) >= 0) {
                if (isset($_FILES["Imagen_Empleado"])) {
                    // SI LA RUTA DEL ARCHIVO NO EXISTE, SE SUBE A LA CARPETA
                    if (!file_exists($Ruta_Imagen_Empleado)) {
                        move_uploaded_file($_FILES["Imagen_Empleado"]["tmp_name"], utf8_decode($Ruta_Imagen_Empleado));
                    }
                }
                $tipoRespuesta = "success";
                $mensaje = "El registro se ha realizado con éxito.";
            }
        } else {
            $tipoRespuesta = "warning";
            $mensaje = "Ya existe un empleado con esa misma cédula.";
        }

        echo json_encode(array("tipoRespuesta" => $tipoRespuesta, "mensaje" => $mensaje, "url" => $url));
    }

    public function vistaVerEmpleado(){
        
    }

    public function vistaEditarEmpleado(){
        $cedula = $_GET["cedula"];
        $nit_sede = $_GET["nit_sede"];

        $sqlEmpleado = "SELECT * FROM empleados AS emple, sedes 
        WHERE emple.Nit_Empresa = sedes.nit_empresa AND emple.Estado='A' 
        AND emple.Cedula_Empleado = '$cedula' AND emple.Nit_Empresa = '$nit_sede'";
        $empleado = $this->Consultar($sqlEmpleado);

        $sqlTiposIdentificacion = "SELECT ti_sigla, ti_descripcion FROM tipo_id WHERE ti_estado='A' ORDER BY ti_descripcion";
        $tiposIdentificacion = $this->Consultar($sqlTiposIdentificacion);

        $sqlSedes = "SELECT nit_empresa, nombre FROM sedes ORDER BY nombre";
        $sedes = $this->Consultar($sqlSedes);

        $sqlCiudades = "SELECT Codigo_Ciudad, Nombre FROM ciudades ORDER BY nombre";
        $ciudades = $this->Consultar($sqlCiudades);

        $sqlCargos = "SELECT Codigo_Cargo, Descripcion FROM cargos ORDER BY Descripcion";
        $cargos = $this->Consultar($sqlCargos);

        $sqlEntidadesSegSocial = "SELECT * FROM entidades_seguridad_social WHERE Estado = 'A' ORDER BY Nombre";
        $entidadesSegSocial = $this->Consultar($sqlEntidadesSegSocial);

        $sqlTiposVinculacion = "SELECT * FROM tipos_vinculacion WHERE Estado = 'A' ORDER BY Descripcion";
        $tiposVinculacion = $this->Consultar($sqlTiposVinculacion);

        $sqlNovedades = "SELECT Cedula_Empleado, Fecha_Novedad,  Descripcion, Observaciones_Novedad, dne.Estado 
        FROM  detalle_novedades_empleados AS dne, novedades_empleados AS ne 
        WHERE dne.Id_Novedad = ne.Id_Novedad AND dne.Estado='A'";
        $novedades = $this->Consultar($sqlNovedades);

        $this->closeConnect();
        
        include_once "../../views/empleado/GuiEditarEmpleado.php";
    }

    public function modalBuscarEmpleado() {
        include_once "../../views/empleado/GuiModalBuscarEmpleado.php";
    }

    function editarEmpleado(){
		extract($_POST);
        extract($_FILES);
        $tipoRespuesta = "error";
        $mensaje = "No se pudo actualizar el empleado, por favor colsulte al administrador";
        $url = "";
		$Ruta = "../../views/Empleados/Archivos/";
        
        $sqlEmpleado="UPDATE empleados SET Nombres='$Nombres', Apellido1='$Apellido1', Apellido2='$Apellido2', 
        Direccion='$Direccion', Fecha_Nacido='$Fecha_Nacido', Cargo='$Cargo', Salario_Basico='" . str_replace(",", "", $Salario_Basico) . "', 
        Fecha_Ingreso='$Fecha_Ingreso', Telefono='$Telefono', Telefono_2='$Telefono_2', Tipo_Ingreso='$Tipo_Ingreso', 
        CiudadResidencia='$CiudadResidencia', LugarNacimiento='$LugarNacimiento', Email='$Email', Email_Corporativo='$Email_Corporativo', 
        Nit_Eps='$Nit_Eps', Nit_Fp='$Nit_Fp', Nit_Fc='$Nit_Fc', Nit_Arl='$Nit_Arl', Nit_Cc='$Nit_Cc', ti_sigla='$ti_sigla' 
        WHERE Cedula_Empleado='$Cedula_Empleado' AND Nit_Empresa='" . decriptar($Nit_Empresa) . "'";
        $this->Actualizar($sqlEmpleado);

        if (mysqli_affected_rows($this->conexion) >= 0) {
            $tipoRespuesta = "success";
            $mensaje = "Registro actualizado con éxito";
            $url = "";
        }

		echo json_encode(array("tipoRespuesta" => $tipoRespuesta, "mensaje" => $mensaje, "url" => $url));
	}

    public function listarEmpleados() {
        extract($_POST);
        $condicion = "";
        $datos = array();

        if ($cedula != "") {
            $condicion = "AND Cedula_Empleado LIKE '%$cedula%' ";
        }
        if ($nombre != "") {
            $condicion .= "AND Nombres LIKE '%$nombre%' ";
        }
        if ($cargo != "") {
            $condicion .= "AND cargos.Descripcion LIKE '%$cargo%' ";
        }
        if ($estado != "" && $estado == "T") {
            $estado = null;
        }

        $sqlListarEmpleados = "SELECT CONCAT(empleados.Nombres,' ', empleados.Apellido1, ' ', empleados.Apellido2) AS Nombre_Completo,
        empleados.Cedula_Empleado, cargos.Descripcion AS Cargo, empleados.Nit_Empresa, empleados.Estado
		FROM empleados, cargos WHERE empleados.Cargo = cargos.Codigo_Cargo
		AND cargos.Estado = 'A' AND empleados.Estado LIKE '%$estado%' $condicion";
        $listarEmpleados = $this->Consultar($sqlListarEmpleados);

        foreach ($listarEmpleados as $listarEmpleado) {
            array_push($datos,
                array(
                    "cedula" => '<button class="btn text-primary">' . $listarEmpleado["Cedula_Empleado"] . '</button>',
                    "nombre" => $listarEmpleado["Nombre_Completo"],
                    "cargo" => $listarEmpleado["Cargo"],
                    "estado" => $listarEmpleado["Estado"],
                    "nit_sede" => $listarEmpleado["Nit_Empresa"]
                ));
        }

        $tabla = array("data" => $datos);

        echo json_encode($tabla);
    }

    function listarNovedadesEmpleado(){
		extract($_POST);
		$condicion="";
		
		if($cedula != ""){
			$condicion .= "AND deta.Cedula_Empleado LIKE '%$cedula%' ";             
		}
		if ($fecha_desde != "" and $fecha_hasta != "") {
			$condicion .= "AND deta.Fecha_Novedad BETWEEN ('$fecha_desde') AND ('$fecha_hasta')";
		}
		if($tipo_novedad != ""){
			$condicion .= "AND deta.Id_Novedad = '$tipo_novedad' ";             
		}
		
		$sqlNovedadesEmpleado = "SELECT deta.Numero_Registro, deta.Cedula_Empleado, deta.Fecha_Novedad, 
		novedad.Descripcion AS Novedad, deta.Observaciones_Novedad, deta.Estado 
		FROM detalle_novedades_empleados AS deta, novedades_empleados AS novedad 
		WHERE deta.Id_Novedad = novedad.Id_Novedad AND deta.Estado LIKE '%%' $condicion 
		ORDER BY deta.Fecha_Novedad DESC";
		$NovedadesEmpleado = $this->Consultar($sqlNovedadesEmpleado);
		
		$datos = array();

		if ($NovedadesEmpleado != null) {
			foreach ($NovedadesEmpleado as $novedadesEmpleado) {
				array_push($datos, 
				array(
					"numero_registro" => $novedadesEmpleado["Numero_Registro"], 
					"cedula" => $novedadesEmpleado["Cedula_Empleado"], 
					"fecha"	=> $novedadesEmpleado["Fecha_Novedad"],  
					"novedad" => $novedadesEmpleado["Novedad"], 
					"observaciones" => $novedadesEmpleado["Observaciones_Novedad"], 
					"estado" => $novedadesEmpleado["Estado"], 
					"eliminar" => '<button type="button" class="btn btn-danger fa fa-trash-alt" data-url="'.getUrl("Empleados", "Empleados", "AnularNovedadEmpleado", false, "ajax").'"></button>',
				));
			}
		}
		
		$tabla = array("data" => $datos);
		
		echo json_encode($tabla);
	}

    public function crearNovedadEmpelado() {
        $fecha = date('Y-m-d');
        $tiposNovedades = $this->consultar("Id_Novedad, Descripcion", "novedades_empleados", "estado='A'");
        include_once '../../views/empleado/GuiCrearNovedad.php';
    }

    public function registrarNovedad() {

        $fecha = $_POST['fecha_novedad'];
        $tipo_novedad = $_POST['tipo_novedad'];
        $observacion = $_POST['observaciones'];
        $cargo = $_POST['cargo'];
        $cedula = $_POST['cedula'];
        $salario = $_POST['salario'];
        $usu_id = $_SESSION['usu_id'];
        //preguntar en que momento generar el codigo
        $this->insertar("detalle_novedades_empleados", "", "'', '$cedula', '$fecha', '$tipo_novedad', '$salario', '$cargo', '$observacion', 'A'");
        alertas("Registro Exitoso");
        redirect(getUrl("empleado", "empleado", "editarEmpleado", array("cedula" => $cedula)));
    }

    public function anularEmpleado() {
        $cedula = $_POST['cedula'];
        $this->editar("empleados",
            "Cedula_Empleado='$cedula'",
            array("Estado" => "'I'"));

    }
}
