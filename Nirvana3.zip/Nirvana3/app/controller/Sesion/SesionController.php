<?php
@session_start();
include_once '../../app/model/MasterModel.php';

class SesionController {

    public function vistaInicioSesion() {
        $ObjSesion = new MasterModel();

        include_once "../../views/sesion/GuiSesion.html.php";
    }

    public function iniciarSesion() {
        extract($_POST);
        $ObjSesion = new MasterModel();
        $tipoRespuesta = "error";
        $mensaje = "Usuario y Contraseña vacíos";
        $url = "";

        if (!empty($usuario) && !empty($contrasena)) {
            $sqlUsuario = "SELECT personas.per_identificacion, CONCAT(per_nombres, ' ', per_apellido1) AS nombre, per_ruta_foto 
            FROM personas, usuarios WHERE personas.per_identificacion = usuarios.per_identificacion
            AND usu_login = '$usuario' and usu_password = '$contrasena' and usu_estado='Activo'";
            $usuario = $ObjSesion->Consultar($sqlUsuario);

            if ($usuario != null) {
                foreach ($usuario as $usu) {
                    $_SESSION["usu_id"] = $usu["per_identificacion"];
                    $_SESSION["usu_nombre"] = $usu["nombre"];
                    $_SESSION["usu_ruta"] = $usu["per_ruta_foto"];
                    $_SESSION["auth"] = "Autorizado";
                    $_SESSION["nit_empresa"] = "";
                }
                $tipoRespuesta = "success";
                $url = "./";
            } else {
                $tipoRespuesta = "warning";
                $mensaje = "Usuario no válido";
            }
        }

        echo json_encode(array("tipoRespuesta" => $tipoRespuesta, "mensaje" => $mensaje, "url" => $url));
    }

    public function cerrarSesion() {
        @session_start();
        @session_destroy();
		
		echo json_encode(array("tipoRespuesta" => true, "url" => getUrl("sesion", "sesion", "vistaInicioSesion", false, "ajax")));
    }

}
